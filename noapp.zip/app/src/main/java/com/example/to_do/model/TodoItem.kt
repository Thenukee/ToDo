package com.example.to_do.model

import java.util.Date
import java.util.UUID

data class TodoItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String = "",
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val dueDate: Long? = null
) {
    /**
     * Convert TodoItem to a Map for Firestore storage
     */
    fun toMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "title" to title,
            "description" to description,
            "isCompleted" to isCompleted,
            "createdAt" to createdAt,
            "dueDate" to dueDate
        )
    }
    
    companion object {
        /**
         * Create TodoItem from Firestore data
         */
        fun fromMap(data: Map<String, Any?>): TodoItem {
            return TodoItem(
                id = data["id"] as? String ?: UUID.randomUUID().toString(),
                title = data["title"] as? String ?: "",
                description = data["description"] as? String ?: "",
                isCompleted = data["isCompleted"] as? Boolean ?: false,
                createdAt = data["createdAt"] as? Long ?: System.currentTimeMillis(),
                dueDate = data["dueDate"] as? Long
            )
        }
    }
}

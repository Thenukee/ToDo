package com.example.to_do.data.firebase

import com.example.to_do.data.entity.SubTaskEntity
import com.example.to_do.data.entity.TaskEntity
import com.example.to_do.data.entity.TaskListEntity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Manager class for Firebase Firestore operations including backup functionality
 */
@Singleton
class FirestoreManager @Inject constructor(
    private val authManager: FirebaseAuthManager
) {
    private val firestore = FirebaseFirestore.getInstance()
    
    /**
     * Backs up a collection of todo items for the current user
     * @param todoItems List of todo items to backup
     * @return success status of the operation
     */
    suspend fun backupTodoItems(todoItems: List<Map<String, Any>>): Boolean {
        val userId = authManager.getCurrentUserId() ?: return false
        
        return try {
            // Create a backup document with timestamp
            val backupData = hashMapOf(
                "timestamp" to System.currentTimeMillis(),
                "items" to todoItems
            )
            
            // Store in users/{userId}/backups/{auto-id}
            firestore.collection("users")
                .document(userId)
                .collection("backups")
                .document()
                .set(backupData)
                .await()
                
            Timber.d("Backup successful for user $userId with ${todoItems.size} items")
            true
        } catch (e: Exception) {
            Timber.e(e, "Backup failed")
            false
        }
    }
    
    /**
     * Retrieves the latest backup for the current user
     * @return The backup data or null if no backup exists or on error
     */
    suspend fun getLatestBackup(): Map<String, Any>? {
        val userId = authManager.getCurrentUserId() ?: return null
        
        return try {
            val snapshot = firestore.collection("users")
                .document(userId)
                .collection("backups")
                .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .limit(1)
                .get()
                .await()
                
            if (snapshot.isEmpty) {
                Timber.d("No backup found for user $userId")
                null
            } else {
                val backup = snapshot.documents[0].data
                Timber.d("Retrieved latest backup for user $userId")
                backup
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to retrieve backup: ${e.message}")
            null
        }
    }
    
    /**
     * Lists all available backups for the current user
     * @return List of backup metadata or empty list if none exist or on error
     */
    suspend fun listBackups(): List<Map<String, Any>> {
        val userId = authManager.getCurrentUserId() ?: return emptyList()
        
        return try {
            val snapshot = firestore.collection("users")
                .document(userId)
                .collection("backups")
                .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .get()
                .await()
                
            snapshot.documents.mapNotNull { doc ->
                doc.data?.let { data ->
                    mapOf(
                        "id" to doc.id,
                        "timestamp" to (data["timestamp"] as? Long ?: 0),
                        "itemCount" to ((data["items"] as? List<*>)?.size ?: 0)
                    )
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to list backups: ${e.message}")
            emptyList()
        }
    }
    
    /**
     * Backs up a list to Firestore
     * @param list The list to back up
     * @return Success status of the operation
     */
    suspend fun backupList(list: TaskListEntity): Boolean {
        val userId = authManager.getCurrentUserId()
        if (userId == null) {
            Timber.e("FirestoreManager: Cannot backup list - user ID is null")
            return false
        }
        
        return try {
            val listData = convertListToMap(list)
            
            Timber.d("FirestoreManager: Backing up list ${list.id} to Firestore for user $userId")
            firestore.collection("users")
                .document(userId)
                .collection("lists")
                .document(list.id)
                .set(listData)
                .await()
                
            Timber.d("FirestoreManager: List backup successful: ${list.name}")
            true
        } catch (e: Exception) {
            Timber.e(e, "FirestoreManager: List backup failed for list ${list.id}: ${e.javaClass.simpleName}: ${e.message}")
            
            // Check for common Firestore errors
            when {
                e.message?.contains("PERMISSION_DENIED") == true -> 
                    Timber.e("FirestoreManager: Permission denied. Check Firestore rules.")
                e.message?.contains("UNAUTHENTICATED") == true -> 
                    Timber.e("FirestoreManager: Authentication issue. User may need to re-authenticate.")
                e.message?.contains("NOT_FOUND") == true -> 
                    Timber.e("FirestoreManager: Document path or collection not found.")
            }
            
            false
        }
    }
    
    /**
     * Backs up a task to Firestore
     * @param listId The ID of the parent list
     * @param task The task to back up
     * @return Success status of the operation
     */
    suspend fun backupTask(listId: String, task: TaskEntity): Boolean {
        val userId = authManager.getCurrentUserId() ?: return false
        
        return try {
            val taskData = convertTaskToMap(task)
            
            firestore.collection("users")
                .document(userId)
                .collection("lists")
                .document(listId)
                .collection("tasks")
                .document(task.id)
                .set(taskData)
                .await()
                
            Timber.d("Task backup successful: ${task.title}")
            true
        } catch (e: Exception) {
            Timber.e(e, "Task backup failed: ${e.message}")
            false
        }
    }
    
    /**
     * Backs up a subtask to Firestore
     * @param listId The ID of the parent list
     * @param taskId The ID of the parent task
     * @param subtask The subtask to back up
     * @return Success status of the operation
     */
    suspend fun backupSubtask(listId: String, taskId: String, subtask: SubTaskEntity): Boolean {
        val userId = authManager.getCurrentUserId() ?: return false
        
        return try {
            val subtaskData = hashMapOf(
                "id" to subtask.id,
                "title" to subtask.title,
                "isCompleted" to subtask.isCompleted,
                "position" to subtask.position
            )
            
            firestore.collection("users")
                .document(userId)
                .collection("lists")
                .document(listId)
                .collection("tasks")
                .document(taskId)
                .collection("subtasks")
                .document(subtask.id)
                .set(subtaskData)
                .await()
                
            true
        } catch (e: Exception) {
            Timber.e(e, "Subtask backup failed: ${e.message}")
            false
        }
    }
    
    // Convert TaskListEntity to a Map that Firestore can store
    private fun convertListToMap(list: TaskListEntity): Map<String, Any?> {
        return hashMapOf(
            "id" to list.id,
            "name" to list.name,
            "color" to list.color,
            "emoji" to list.emoji,
            "createdAt" to list.createdAt,
            "position" to list.position
        )
    }
    
    // Convert TaskEntity to a Map that Firestore can store
    private fun convertTaskToMap(task: TaskEntity): Map<String, Any?> {
        val taskMap = hashMapOf<String, Any?>(
            "id" to task.id,
            "title" to task.title,
            "description" to task.description,
            "isCompleted" to task.isCompleted,
            "isImportant" to task.isImportant,
            "isInMyDay" to task.isInMyDay,
            "createdAt" to task.createdAt,
            "modifiedAt" to task.modifiedAt,
            "position" to task.position,
            "listId" to task.listId
        )
        
        // Add nullable fields
        task.dueDate?.let { taskMap["dueDate"] = it }
        task.reminderTime?.let { taskMap["reminderTime"] = it }
        
        return taskMap
    }
}

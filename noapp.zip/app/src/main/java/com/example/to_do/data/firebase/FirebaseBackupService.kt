package com.example.to_do.data.firebase

import com.example.to_do.data.entity.AttachmentEntity
import com.example.to_do.data.entity.SubTaskEntity
import com.example.to_do.data.entity.TaskEntity
import com.example.to_do.data.entity.TaskListEntity
import com.example.to_do.data.repository.TaskRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.util.HashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Service to coordinate backup operations between Room and Firestore
 */
@Singleton
class FirebaseBackupService @Inject constructor(
    private val firebaseAuthManager: FirebaseAuthManager,
    private val firestoreManager: FirestoreManager,
    private val taskRepository: TaskRepository
) {
    /**
     * Performs a complete backup of all user data to Firebase Firestore
     * @return true if backup was successful, false otherwise
     */
    suspend fun performFullBackup(): Boolean {
        Timber.d("FirebaseBackupService: Starting performFullBackup process")
        
        try {
            // Make sure user is signed in
            if (!firebaseAuthManager.isSignedIn()) {
                Timber.e("FirebaseBackupService: Cannot backup: User is not signed in")
                return false
            }
            
            // Try to ensure user is signed in (will create anonymous account if needed)
            Timber.d("FirebaseBackupService: Ensuring user is signed in...")
            if (!firebaseAuthManager.ensureSignedIn()) {
                Timber.e("FirebaseBackupService: Cannot backup: Failed to ensure user is signed in")
                return false
            }

            val userId = firebaseAuthManager.getCurrentUserId()
            if (userId == null) {
                Timber.e("FirebaseBackupService: Cannot backup: User ID is null despite being signed in")
                return false
            }
            
            Timber.d("FirebaseBackupService: Starting backup for user: $userId")

            try {
                // Get all lists
                val allLists = withContext(Dispatchers.IO) {
                    taskRepository.getAllListsSync()
                }
                
                if (allLists.isEmpty()) {
                    Timber.d("No lists to backup")
                    return true // Successfully backed up nothing
                }
                
                Timber.d("Retrieved ${allLists.size} lists to backup")

                // Upload each list and its tasks
                allLists.forEach { list ->
                    // Backup list
                    Timber.d("Attempting to backup list: ${list.id} - ${list.name}")
                    val listResult = firestoreManager.backupList(list)
                    if (!listResult) {
                        Timber.w("Failed to backup list: ${list.id}")
                        return@forEach
                    }

                    // Get tasks for this list
                    val tasks = withContext(Dispatchers.IO) {
                        taskRepository.getTasksByListSync(list.id)
                    }

                    // Backup each task
                    tasks.forEach { task ->
                        val taskResult = firestoreManager.backupTask(list.id, task)
                        if (!taskResult) {
                            Timber.w("Failed to backup task: ${task.id}")
                        }

                        // Get subtasks for this task
                        val subtasks = withContext(Dispatchers.IO) {
                            taskRepository.getSubTasksForTaskSync(task.id)
                        }

                        // Backup each subtask
                        subtasks.forEach { subtask ->
                            val subtaskResult = firestoreManager.backupSubtask(list.id, task.id, subtask)
                            if (!subtaskResult) {
                                Timber.w("Failed to backup subtask: ${subtask.id}")
                            }
                        }
                    }
                }

                Timber.d("FirebaseBackupService: Backup completed successfully")
                return true
            } catch (e: Exception) {
                Timber.e(e, "FirebaseBackupService: Error during backup: ${e.javaClass.simpleName}: ${e.message}")
                e.printStackTrace()
                
                // Check for common Firestore errors
                if (e.message?.contains("PERMISSION_DENIED") == true) {
                    Timber.e("FirebaseBackupService: Permission denied error. Check Firestore rules.")
                } else if (e.message?.contains("UNAUTHENTICATED") == true) {
                    Timber.e("FirebaseBackupService: Authentication failed. User may need to re-authenticate.")
                } else if (e.message?.contains("UNAVAILABLE") == true) {
                    Timber.e("FirebaseBackupService: Service unavailable. Network connectivity issues.")
                }
                
                return false
            }
        } catch (e: Exception) {
            Timber.e(e, "FirebaseBackupService: Authentication error: ${e.message}")
            return false
        }
    }

    /**
     * Returns the count of items that were backed up in the last backup operation
     * @return Number of backed up items, or null if no backup was performed
     */
    suspend fun getBackupItemCount(): Int? {
        Timber.d("FirebaseBackupService: Getting backup item count")
        
        if (!firebaseAuthManager.isSignedIn()) {
            Timber.w("FirebaseBackupService: Cannot get item count, user not signed in")
            return null
        }

        try {
            var totalCount = 0

            // Get all lists
            val allLists = withContext(Dispatchers.IO) {
                taskRepository.getAllListsSync()
            }
            Timber.d("FirebaseBackupService: Found ${allLists.size} lists")
            totalCount += allLists.size

            // Count all tasks and subtasks
            allLists.forEach { list ->
                // Get tasks for this list
                val tasks = withContext(Dispatchers.IO) {
                    taskRepository.getTasksByListSync(list.id)
                }
                totalCount += tasks.size

                // Count subtasks for each task
                tasks.forEach { task ->
                    val subtasks = withContext(Dispatchers.IO) {
                        taskRepository.getSubTasksForTaskSync(task.id)
                    }
                    totalCount += subtasks.size
                }
            }

            Timber.d("FirebaseBackupService: Total items counted: $totalCount")
            return totalCount
        } catch (e: Exception) {
            Timber.e(e, "FirebaseBackupService: Error getting backup item count: ${e.message}")
            e.printStackTrace()
            return null
        }
    }

    /**
     * Restore data from the latest backup
     * @return true if restore was successful, false otherwise
     */
    suspend fun restoreFromLatestBackup(): Boolean {
        // Implementation for restore functionality
        // This would involve fetching data from Firestore and importing it to Room
        return false // Placeholder
    }
}

